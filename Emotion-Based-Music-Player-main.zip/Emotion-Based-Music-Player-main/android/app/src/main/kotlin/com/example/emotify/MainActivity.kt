package com.example.emotify

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
